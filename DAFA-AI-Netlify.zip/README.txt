DAFA AI — paket website + backend Netlify

ISI:
- index.html
- netlify.toml
- netlify/functions/chat.mjs

PENTING:
1. Paket ini belum terhubung ke akun Netlify atau OpenAI milikmu.
2. API key OpenAI harus dibuat/dikelola oleh orang tua/wali jika diperlukan, dan jangan pernah ditaruh di HTML atau dikirim lewat chat.
3. Unggah folder proyek ini ke Netlify dengan metode deploy yang mendukung Netlify Functions.
4. Di pengaturan environment variables Netlify, tambahkan:
   Nama: OPENAI_API_KEY
   Nilai: API key rahasia milik akun yang mengelola layanan.
5. Deploy ulang. Buka situs Netlify yang sudah di-deploy untuk mencoba chat.

Model di fungsi saat ini: gpt-6-luna. Ketersediaan model dan akses API mengikuti akun OpenAI dan pengaturan layanan.
